import tweepy
from secrets_twit import get_secrets
from pprint import pprint
from producer import producer
import time


class MyStreamListener(tweepy.StreamListener):

    def __init__(self, time_limit=600):
        self.start_time = time.time()
        self.limit = time_limit
        super(MyStreamListener, self).__init__()

    def on_connect(self):
        print("Connected to Twitter API.")

    def on_status(self, status):
        print(status)
        producer.send('twitter', status._json)

        if (time.time() - self.start_time) > self.limit:
            print(time.time(), self.start_time, self.limit)
            return False

    def on_error(self, status_code):
        if status_code == 420:
            # Returning False in on_data disconnects the stream
            return False


twitter = get_secrets()

api_key = twitter['API Key']  # api_key
api_secret_key = twitter["API Key Secret"]  # api_secret_key
access_token = twitter["Access Token"]  # # access_token
access_token_secret = twitter["Access Token Secret"]  # access_token_secret

# authorize the API Key
authentication = tweepy.OAuthHandler(api_key, api_secret_key)

# authorization to user's access token and access token secret
authentication.set_access_token(access_token, access_token_secret)

# call the api
api = tweepy.API(authentication)

myStreamListener = MyStreamListener()
myStream = tweepy.Stream(auth=api.auth, listener=myStreamListener,
                         tweet_mode="extended")
myStream.filter(track=['Bangalore','Bengaluru '])
