from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession


def connect_to_kafka_stream(topic_name, spark_session):
    return (spark_session
            .readStream
            .format("kafka")
            .option("kafka.bootstrap.servers", "http://kafka-1:9092")
            .option("subscribe", topic_name)
            .load())


conf = SparkConf() \
    .setAppName("twitter") \
    .setMaster("spark://spark-master:7077")

sc = SparkContext(conf=conf)

spark = SparkSession.builder \
    .config(conf=conf) \
    .getOrCreate()

sc.setLogLevel("ERROR")

df = connect_to_kafka_stream(
        topic_name="twitter", spark_session=spark)

query = (df.selectExpr("CAST(value AS STRING) AS json")
         .writeStream
         .option("truncate", "false")
         .outputMode("append")
         .format("console")
         .start()
         )
query.awaitTermination()

