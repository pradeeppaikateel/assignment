
def get_secrets():
    twitter = {
        "API Key": "TEdOLhwzoPHyNHrCE56JvJHLS",
        "API Key Secret": "yHd3v1YalBa0TmVe3h6rDheCrOlFlO3Q3dlOzE9rximacVsJkq",
        "Bearer Token": "Bearer Token",
        "Access Token": "968582543615430668-M1zZ8eriehpVpfQwGFVFepv2juJRE2l",
        "Access Token Secret": "HPNUpjcad2HC2x1qNk5MZ1BMwDh9Qzn62B2XVqbDCjJb7"
    }
    return twitter
