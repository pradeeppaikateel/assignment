import argparse
from datetime import datetime


def parse_job_args(args=None):
    """
    Parses the job arguments passed in the driver program
    :param args: List of arguments
    :return:
        argparse.Namespace: Job arguments
    """
    parser = argparse.ArgumentParser(description="Run an ETL job")

    parser.add_argument(
        "--job_name",
        required=True,
        help="This is the name of the script to be run like etc."
    )
    parser.add_argument(
        "--env",
        required=True,
        help="Environment"
    )
    parser.add_argument(
        "--ad_hoc_date",
        required=False,
        default=datetime.today().strftime("%Y-%m-%d"),
        help="Custom input date to be parsed as var_date"
    )
    parser.add_argument(
        "--var1",
        required=False,
        default=None,
        help="batch_id, defaulted as None"
    )

    args = parser.parse_args(args)
    return args
