# -*- coding: utf-8 -*-

import logging
import os
from pathlib import Path
from .utils import log_cleaner


class Logger:
    def __init__(
            self,
            object_name,
            log_path,
            session_id,
            formatter=logging.Formatter(
                "%(asctime)s : %(levelname)s : %(name)s: %(message)s"
            ),
            level=logging.INFO,
    ):
        self.logger = Logger._setup_logger(object_name, session_id, log_path, formatter, level)

    @staticmethod
    def _setup_logger(object_name, session_id, log_path, formatter, level):
        log_cleaner(file_path=log_path)
        logger = logging.getLogger(object_name)
        logger.setLevel(level)
        os.umask(0)
        absolute_path = os.path.abspath(log_path)
        if not log_path.endswith("\\"):
            log_path = log_path + "\\"
        if "src" in log_path:
            path = Path(
                absolute_path.split("src")[0]
                + r"logs\\"
                + session_id
                + "_"
                + object_name
                + ".log"
            )
        else:
            path = Path(
                log_path
                + session_id
                + "_"
                + object_name
                + ".log"
            )
        file_handler = logging.FileHandler(path)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        logger.propagate = False

        # stream_handler = logging.StreamHandler()
        # stream_handler.setFormatter(formatter)
        # logger.addHandler(stream_handler)

        return logger

    def get_logger(self):
        return self.logger
