#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pathlib import Path
import smtplib
import os
from .config_parser import ConfigParser
from os.path import basename
from .db_conn import fetch_data_postgres
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate
import datetime


def _send_mail(send_from, send_to, cc_to, bcc_to, subject, Body, files, server):
    assert isinstance(send_to, list)
    assert isinstance(cc_to, list)

    msg = MIMEMultipart()
    msg['From'] = send_from
    msg['To'] = ','.join(send_to)
    msg['Cc'] = ','.join(cc_to)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    msg.attach(MIMEText(Body))

    for f in files or []:
        with open(f, "rb") as fil:
            part = MIMEApplication(
                fil.read(),
                Name=basename(f)
            )
        # After the file is closed
        part['Content-Disposition'] = 'attachment; filename="%s"' % basename(f)
        msg.attach(part)

    smtp = smtplib.SMTP(server)
    smtp.sendmail(send_from, (send_to + cc_to + bcc_to), msg.as_string())
    smtp.close()


def smtp_automail_failure(env: str, err: str, ad_hoc_date: str, session_id: str, file_path,files : list = None, prime_logger=None,object_name : str = "",username=None,password=None):
    """
    This function triggers failure emails for the framework
    :param env: environment in which the framework is running in
    :param err: Error Message
    :param object_name: Object Name for the job
    :param ad_hoc_date: Date for which the job is intended to run
    :param session_id: session number of the job
    :param file_path: file path from where this function is being called
    :param files: additional files to be sent with the email notifier
    :param prime_logger: the logger instance that is to be passed
    :return: None
    """
    files_f = []
    if prime_logger is not None:
        logger = prime_logger.get_logger()
        logger.info(f"Sending email for error notification")

    run_date = datetime.datetime.today()
    absolute_path = os.path.abspath(file_path)
    if not file_path.endswith("\\"):
            file_path = file_path + "\\"
    if prime_logger is not None:
        if "src" in file_path:
            path = Path(
                absolute_path.split("src")[0]
                + r"logs\\"
                + session_id
                + "_"
                + object_name
                + ".log"
            )
        else:
            path = Path(
                file_path
                + session_id
                + "_"
                + object_name
                + ".log"
            )
        files_f.append(path)
    if files is not None:
        files_f.extend(files)

    if "src" in absolute_path:
        framework_name = absolute_path.split("src")[0].split("\\")[-2]
    else:
        framework_name = object_name

    query_parameter = f"{framework_name.lower()} {object_name.lower()}"

    sql_query_1 = f"SELECT sender_id, to_id, cc_id, bcc_id " \
                  + "from uno_ds.prod_proc_email_dl_list " \
                  + f"where process_name = '{query_parameter}' "

    

    df_1 = fetch_data_postgres(env, prime_logger=prime_logger, sql_query=sql_query_1,username=username,password=password)
    if df_1.empty:
        raise Exception("No DL found for the process")
    send_from = df_1.at[0, "sender_id"]
    send_to = [] if df_1.at[0, "to_id"] is None else df_1.at[0, "to_id"].split(",")
    cc_to = [] if df_1.at[0, "cc_id"] is None else df_1.at[0, "cc_id"].split(",")
    bcc_to = [] if df_1.at[0, "bcc_id"] is None else df_1.at[0, "bcc_id"].split(",")

    config = ConfigParser(env,username=username,password=password)
    server = config.smtp_ip

    body = f'''
Hello Team,

An error was encountered while executing an ETL script.

Error : {err}

Object: {framework_name.upper()} : {object_name}

Session_id: {session_id}

Input_Date: {ad_hoc_date}

Run_date: {str(run_date)}

env: {env.upper()}

PFA the log file for the same with this mail.

Please do not reply to this mail, this is a system generated mail.

Regards
Data Engineering Team,
Business Intelligence Unit
    '''

    subject = f"ETL Job Failure | {framework_name.upper()} : {object_name}"
    if prime_logger is not None:
        logger.info("Email has been sent")
        logger.info(
            "**********************************************************************************************************"
        )
    _send_mail(send_from, send_to, cc_to, bcc_to, subject, body, files_f, server)


def smtp_automail_success(env: str, ad_hoc_date: str, session_id: str, file_path,files : list = None, prime_logger=None,object_name : str = "",username=None,password=None):
    """
        This function triggers success emails for the framework
        :param env: environment in which the framework is running in
        :param object_name: Object Name for the job
        :param ad_hoc_date: Date for which the job is intended to run
        :param session_id: session number of the job
        :param file_path: file path from where this function is being called
        :param files: additional files to be sent with the email notifier
        :param prime_logger: the logger instance that is to be passed
        :return: None
        """
    files_f=[]

    if prime_logger is not None:
        logger = prime_logger.get_logger()
        logger.info(f"Sending email for success notification")

    run_date = datetime.datetime.today()
    absolute_path = os.path.abspath(file_path)
    if not file_path.endswith("\\"):
            file_path = file_path + "\\"
    if prime_logger is not None:
        if "src" in file_path:
            path = Path(
                absolute_path.split("src")[0]
                + r"logs\\"
                + session_id
                + "_"
                + object_name
                + ".log"
            )
        else:
            path = Path(
                file_path
                + session_id
                + "_"
                + object_name
                + ".log"
            )
        files_f.append(path)
    if files is not None:
        files_f.extend(files)
    
    if "src" in absolute_path:
        framework_name = absolute_path.split("src")[0].split("\\")[-2]
    else:
        framework_name = object_name

    query_parameter = f"{framework_name.lower()} {object_name.lower()}"
    
    sql_query_1 = f"SELECT sender_id, to_id, cc_id, bcc_id " \
                  + "from uno_ds.prod_proc_email_dl_list " \
                  + f"where process_name = '{query_parameter}' "

    df_1 = fetch_data_postgres(env, prime_logger=prime_logger, sql_query=sql_query_1,username=username,password=password)

    if df_1.empty:
        raise Exception("No DL found for the process")

    send_from = df_1.at[0, "sender_id"]
    send_to = [] if df_1.at[0, "to_id"] is None else df_1.at[0, "to_id"].split(",")
    cc_to = [] if df_1.at[0, "cc_id"] is None else df_1.at[0, "cc_id"].split(",")
    bcc_to = [] if df_1.at[0, "bcc_id"] is None else df_1.at[0, "bcc_id"].split(",")

    config = ConfigParser(env,username=username,password=password)
    server = config.smtp_ip

    body = f'''
Hello Team,

ETL process was successful

Object: {framework_name.upper()} : {object_name}

Session_id: {session_id}

Input_Date: {ad_hoc_date}

Run_date: {str(run_date)}

env: {env.upper()}

PFA the log file for the same with this mail.

Please do not reply to this mail, this is a system generated mail.

Regards
Data Engineering Team,
Business Intelligence Unit
    '''

    subject = f"ETL Job Success | {framework_name.upper()} : {object_name}"

    if prime_logger is not None:
        logger.info("Email has been sent")
        logger.info(
            "**********************************************************************************************************"
        )
    _send_mail(send_from, send_to, cc_to, bcc_to, subject, body, files_f, server)
