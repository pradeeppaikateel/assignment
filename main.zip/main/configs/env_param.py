configs={
    "dev":
        {
            "host_prod" : None,
            "host_rep" : None,
            "user" : None,
            "password" : None,
            "database" : None,
            "port" : None,
            "smtp_ip" : None
        },
    "uat":
        {
            "host_prod" : "",
            "host_rep" : "",
            "user" : None,
            "password" : None,
            "database" : "",
            "port" : "",
            "smtp_ip" : "",
        },
    "prod":
        {
            "host_prod" : "",
            "host_rep" : "",
            "user" : None,
            "password" : None,
            "database" : "",
            "port" : "",
            "smtp_ip" : "",
        }
}