#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .config_parser import ConfigParser
import pandas as pd
from sqlalchemy import create_engine
from dateutil.relativedelta import *
from datetime import datetime


def postgres_server_conn(url_string):
    conn_string = url_string
    engine = create_engine(conn_string)
    conn = engine.raw_connection()
    return engine, conn


def fetch_data_postgres(env, sql_query, prime_logger=None,username= None, password = None):
    """
    This function retrieves the data from postgres database as per the query given as input.
    :param prime_logger: Logger Instance
    :param sql_query: Query to be fired to server
    :return: DataFrame containing Database data
    """
    if prime_logger is not None:
        logger = prime_logger.get_logger()
        logger.info(f"Fetching data from DB for query : {sql_query}")
    try:
        config = ConfigParser(env,username=username,password=password)
        engine, conn = postgres_server_conn(config.url_string_read)
        cursor = conn.cursor()
        cursor.execute(sql_query)
        query_out = cursor.fetchall()
        query_col_names = [item[0] for item in cursor.description]
        df_out = pd.DataFrame(query_out)
        if not df_out.empty:
            df_out.columns = query_col_names
        cursor.close()
        conn.close()
        engine.dispose()
        del config
        return df_out
    except Exception as err:
        if prime_logger is not None:
            logger.error(
                f"Failed to retrieve data from database for sql_query: '{sql_query}'"
            )
        raise err


def append_data_postgres(env, df, table_name, schema_name, prime_logger=None, chunk_size=5000,username= None, password = None):
    """
    This function appends the data from dataframe to postgres database and creates the table
    if not exists
    :param prime_logger: Logger Instance
    :param df: Dataframe with data to be inserted
    :param table_name: Target table name
    :param schema_name: Target Schema Name
    :param chunk_size: Instance of data to be inserted at once
    :return: None
    """
    if prime_logger is not None:
        logger = prime_logger.get_logger()
        logger.info(f"Inserting data to table {schema_name}.{table_name}")
    try:
        config = ConfigParser(env,username=username,password=password)
        engine, conn = postgres_server_conn(config.url_string_write)
        df.to_sql(
            table_name,
            engine,
            if_exists="append",
            index=False,
            schema=schema_name,
            chunksize=chunk_size,
            method="multi",
        )
        conn.close()
        engine.dispose()
        del config
    except Exception as err:
        if prime_logger is not None:
            logger.error(
                f"Failed in inserting data to table {schema_name}.{table_name} with error as '{err}'"
            )
        raise err


def truncate_data_postgres(env, table_name, schema_name,prime_logger=None,username= None, password = None):
    """
    This function truncates the data from postgres database as per schema and table provided.
    :param schema_name: schema name to be truncated
    :param prime_logger: Logger Instance
    :param table_name: table name to be truncated
    :return: Boolean: True if truncated , else False
    """
    if prime_logger is not None:
        logger = prime_logger.get_logger()
        logger.info(f" Truncating table: {schema_name}.{table_name}")
    try:
        config = ConfigParser(env,username=username,password=password)
        engine, conn = postgres_server_conn(config.url_string_write)
        cursor = conn.cursor()
        engine.execute(f'TRUNCATE TABLE {schema_name}."{table_name}";')
        conn.commit()
        cursor.close()
        conn.close()
        engine.dispose()
        del config
        logger.info(f" Table has been truncated: {schema_name}.{table_name}")
        return True
    except Exception as err:
        if prime_logger is not None:
            logger.error(
                f"Failed to Truncate table: {schema_name}.{table_name} : '{err}'"
            )


def truncate_load_data_postgres(env, df, created_date, table_name, schema_name, prime_logger=None, chunk_size=5000,username= None, password = None):
    """
    This function truncates and inserts the data from input dataframe to postgres database and creates the table
    if not exists
    :param chunk_size: Instance of data to be inserted at once
    :param prime_logger: Logger Instance
    :param df: Dataframe with data to be inserted
    :param created_date: Current date
    :param table_name: Target table name
    :param schema_name: Target Schema name
    :return: None
    """
    if prime_logger is not None:
        logger = prime_logger.get_logger()
        logger.info(f"Inserting data to table {schema_name}.{table_name}")
    try:
        trunc = truncate_data_postgres(env=env, prime_logger=prime_logger, schema_name=schema_name,table_name=table_name,username=username,password=password)
        config = ConfigParser(env,username=username,password=password)
        engine, conn = postgres_server_conn(config.url_string_write)
        df["active_flag"] = "true"
        df["created_date"] = created_date
        df.to_sql(
            table_name,
            engine,
            if_exists="append",
            index=False,
            method="multi",
            schema=schema_name,
            chunksize=chunk_size
        )
        conn.close()
        engine.dispose()
        del config
    except Exception as err:
        if prime_logger is not None:
            logger.error(
                f"Failed in inserting data to table {schema_name}.{table_name} with error as '{err}'"
            )
        raise err
        
def execute_query_postgres(env, sql_query, prime_logger=None,username= None, password = None):
    """
    This function executes the query postgres database as per the query given as input.
    :param prime_logger: Logger Instance
    :param sql_query: Query to be fired to server
    :return: DataFrame containing Database data
    """
    if prime_logger is not None:
        logger = prime_logger.get_logger()
        logger.info(f"Executing query : {sql_query}")
    try:
        config = ConfigParser(env,username=username,password=password)
        engine, conn = postgres_server_conn(config.url_string_write)
        cursor = conn.cursor()
        engine.execute(sql_query)
        cursor.close()
        conn.close()
        engine.dispose()
        del config
    except Exception as err:
        if prime_logger is not None:
            logger.error(
                f"Failed to execute sql_query: '{sql_query}'"
            )
        raise err
