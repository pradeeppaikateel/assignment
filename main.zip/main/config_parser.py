#!/usr/bin/env python
# -*- coding: utf-8 -*-

import yaml
import os
from urllib.parse import quote



class ConfigParser:
    '''
    This class has been built to retrieve the run and environment configurations.
    Query the following to get respective configurations \n
    Input: Environment  example config = ConfigParser("prod") \n
    Attributes: \n
    env | url_string_read | url_string_write | smtp_ip\n
    Methods:\n
    get_run_param(path): Returns the parameters (key value pairs) configured in a yaml file given as input path
    '''

    def __init__(self, env,username = None, password = None):
        self.env = env
        self.__cust_user = username
        self.__cust_pass = password
        self.__config = self.__get_configs()
        self.__host_main = self.__get_host_prod()
        self.__host_rep = self.__get_host_rep()
        self.__user = self.__get_user() 
        self.__password = self.__get_password()
        self.__database = self.__get_database()
        self.__port = self.__get_port()
        self.url_string_read = self.__get_url_string_read()
        self.url_string_write = self.__get_url_string_write()
        self.smtp_ip = self.__get_smtp_ip()

    def __get_configs(self):
        from .configs import env_param
        env = self.__get_env()
        configs=env_param.configs
        try:
            con = configs
            return con[env.lower()]
        except Exception as E:
            raise Exception(
                f"The following error was raised while trying to read config parameter: {E}"
            ) from E

    def get_run_param(self, path):
        try:
            path = path
            with open(path, "r") as config_file:
                run_configs = yaml.safe_load(config_file)
            return run_configs
        except Exception as E:
            raise Exception(
                f"The following error was raised while trying to read run parameter: {E}"
            ) from E

    def __get_env(self):
        return self.env

    def __get_host_prod(self):
        return self.__config["host_prod"]

    def __get_smtp_ip(self):
        return self.__config["smtp_ip"]

    def __get_host_rep(self):
        return self.__config["host_rep"]

    def __get_user(self):
        
        if self.__config["user"] is not None:
            return self.__config["user"]
        else:
            return self.__cust_user
        

    def __get_password(self):
        if self.__config["password"] is not None:
            return quote(self.__config["password"])
        else:
            return quote(self.__cust_pass)

    def __get_database(self):
        return self.__config["database"]

    def __get_port(self):
        return self.__config["port"]

    def __get_url_string_read(self):
        conn_string = (
                r"postgresql+psycopg2://"
                + self.__get_user()
                + r":"
                + self.__get_password()
                + r"@"
                + self.__get_host_rep()
                + r":"
                + self.__get_port()
                + r"/"
                + self.__get_database()
        )
        return conn_string

    def __get_url_string_write(self):
        conn_string = (
                r"postgresql+psycopg2://"
                + self.__get_user()
                + r":"
                + self.__get_password()
                + r"@"
                + self.__get_host_prod()
                + r":"
                + self.__get_port()
                + r"/"
                + self.__get_database()
        )
        return conn_string
