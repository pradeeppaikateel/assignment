#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta
import os
import numpy as np
from .db_conn import truncate_load_data_postgres


def panda_print(df):
    """
    This function prints the dataframe without truncation
    :param df: Input dataframe
    :return:
    """

    pd.set_option("display.max_rows", None)
    pd.set_option("display.max.columns", None)
    pd.set_option("display.width", 2000)
    pd.set_option("display.float_format", "{:20,.2f}".format)
    pd.set_option("display.max_colwidth", None)
    print(df)
    pd.reset_option("display.max_rows")
    pd.reset_option("display.max.columns")
    pd.reset_option("display.width")
    pd.reset_option("display.float_format")
    pd.reset_option("display.max_colwidth")


def log_cleaner(file_path, days=15):
    """
        This function cleans the logs greater than 15 days
        :param file_path: __file__ of driver file
        :param days: Number of days for which the log needs to be retained
        :return:
        """
    absolute_path = os.path.abspath(file_path)

    criticalTime = datetime.now() - timedelta(days=days)

    path = Path(
        absolute_path.split("src")[0]
        + r"logs\\")

    for item in Path(path).glob('*'):
        if item.is_file():
            timestamp_str = datetime.fromtimestamp(item.stat().st_mtime)
            if timestamp_str < criticalTime:
                os.remove(item)


def csv_to_postgres(env, path: str, schema_name: str, table_name: str,username=None,password=None, **kwargs):
    """

    :param path: path of csv file
    :param schema_name: target schema name
    :param table_name: target table name
    :param kwargs: additional arguments as needed by pd.read_csv if needed, eg, sep, header etc
    :return: returns boolean True if job succeeds else false
    """
    try:
        df = pd.read_csv(path, kwargs)
        schema = schema_name
        table_name = table_name
        created_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        truncate_load_data_postgres(env=env, table_name=table_name, df=df, schema_name=schema,
                                    created_date=created_date,username=username,password=password)
        return True

    except Exception as E:
        raise E
